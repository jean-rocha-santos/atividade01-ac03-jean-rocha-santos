package school.sptech;

public enum Status {
    PENDENTE,
    EM_PREPARO,
    CONCLUIDO;

}
